import java.util.Collections;
import java.util.Scanner;
import java.util.Stack;

/**
 * This program reads a list of integer numbers from user input,
 * stores them in a Stack, sorts them in ascending order,
 * and prints the sorted stack in Last-In-First-Out (LIFO) order.
 *
 * This is a maintenance task modifying the previous LinkedList implementation
 * to use a Stack instead, as part of adapting our infrastructure.
 *
 * @author Joseph Tadonkeng
 * @version 2.0
 */
public class SortedStack {

    /**
     * Reads integers from standard input, stores them in a stack,
     * sorts the stack, and prints the sorted numbers in LIFO order.
     *
     * @param args Command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Scanner to read user input
        Scanner scanner = new Scanner(System.in);
        Stack<Integer> numbers = new Stack<>();

        System.out.println("Enter integers (type 'done' to finish):");

        // Read user input until "done" is entered
        while (scanner.hasNext()) {
            if (scanner.hasNextInt()) {
                numbers.push(scanner.nextInt()); // Push elements onto the stack
            } else {
                String input = scanner.next();
                if (input.equalsIgnoreCase("done")) {
                    break;
                } else {
                    System.out.println("Invalid input, please enter an integer or 'done'.");
                }
            }
        }

        // Close scanner to prevent resource leaks
        scanner.close();

        // Sort the stack in ascending order
        Collections.sort(numbers);

        // Print sorted stack in LIFO order
        System.out.println("Sorted numbers in LIFO order:");
        while (!numbers.isEmpty()) {
            System.out.println(numbers.pop()); // Popping elements (LIFO order)
        }
    }
}
