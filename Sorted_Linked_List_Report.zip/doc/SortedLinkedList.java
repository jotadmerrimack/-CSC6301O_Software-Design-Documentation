import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * A program that reads a list of integer numbers from standard input,
 * stores them in a LinkedList, sorts them in ascending order, and displays the result.
 *
 * @author joseph Tadonkeng
 * @version 1.0
 */
public class SortedLinkedList {

    /**
     * Reads integers from standard input and returns a sorted LinkedList.
     *
     * @return A sorted LinkedList of integers.
     */
    public static LinkedList<Integer> getSortedNumbers() {
        LinkedList<Integer> numbers = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter integer numbers (press Enter after each number, type 'done' to finish):");

        while (true) {
            if (scanner.hasNextInt()) {
                numbers.add(scanner.nextInt()); // Read an integer and add it to the list
            } else {
                String input = scanner.next(); // Read the next input as a string
                if (input.equalsIgnoreCase("done")) {
                    break; // Exit loop when 'done' is entered
                }
                System.out.println("Invalid input! Please enter an integer or 'done' to finish.");
            }
        }
        scanner.close();

        // Sort the numbers
        Collections.sort(numbers);
        return numbers;
    }

    /**
     * Main method to execute the program.
     *
     * @param args Command-line arguments (not used)
     */
    public static void main(String[] args) {
        LinkedList<Integer> sortedNumbers = getSortedNumbers();
        System.out.println("Sorted Numbers: " + sortedNumbers);
    }
}
